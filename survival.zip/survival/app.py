from person import *
from enemy import *
import pandas as pd
import numpy as np


with open("input2.txt") as f:
    sentences = f.readlines()
# Hero ve enemy karşılatığı zaman bu fonksiyon çağrılıyor
# Heronun canını geri dönderiyor


def attack_time(hero, enemy):
    # Hayvanın saldırısından sonra insanın kalan hp si
    attack_num = enemy.hp / hero.attack
    enemyOf = attack_num * enemy.attack
    # İnsanın saldırınıdan sonra hayvanın kalan hp'si
    mod = (hero.hp - enemyOf) % 10
    return int(hero.hp - enemyOf) - int(mod)


def defeated(hero, enemy):
    attack_num2 = hero.hp / enemy.attack
    heroOf = attack_num2 * hero.attack
    return int(heroOf - enemy.hp)

# Dosya içindeki cümleleri diziye attım.
sentences = [x.strip() for x in sentences]
# Dizideki cümleleri tek tek paketlere ayırdım.
sentences = [x.split() for x in sentences]

# Elde edilen sayıların integer olarak tanımladım.
resource = int(sentences[0][2])
hp = int(sentences[1][2])
attack = int(sentences[2][3])

hero = Person(resource, hp, attack)  # Kahraman nesnesi

# Düşmanları tanımlayıp okuduğum dosyadan alıyorum.

enemies_name = []
enemies_hp = []
enemies_attack = []

# İlk başta satırlarda olan özel kelimeler belirledim ve bunlara göre özellikleri çektim.

for x in range(len(sentences)):
    if(sentences[x][2] == 'Enemy'):
        enemies_name.append(sentences[x][0])

for k in enemies_name:
    for j in range(3 + len(enemies_name), len(sentences)):
        if(sentences[j][0] == k and sentences[j][3] == 'hp'):
            enemies_hp.append(int(sentences[j][2]))
        if(sentences[j][0] == k and sentences[j][1] == 'attack'):
            enemies_attack.append(int(sentences[j][3]))

# Bu bölümde de düşmanların pozisyonlarını ve adlarını alıp sıraladım. Son işlemler için
# hazır hale getirdim.
story = []
for l in range(len(sentences)):
    if(sentences[l][0] == 'There'):
        tmp = []
        tmp.append(sentences[l][3])
        tmp.append(int(sentences[l][6]))
        story.append(tmp)

story_list_sorted = sorted(story, key=lambda x: x[1])
print("Hero started journey with {} HP!".format(hero.hp))

for i in story_list_sorted:
    tmp = i[1]
    # Sıradaki enemy nesnesi tanımlanıyor
    for x in range(len(enemies_name)):
        if(i[0] == enemies_name[x]):
            tmpEnemy = Enemy(enemies_name[x], enemies_hp[x], enemies_attack[x])

    if(hero.hp > 0):
        tmpHero = hero
        hero.hp = attack_time(hero, tmpEnemy)
        if(hero.hp <= 0 and hero.hp < tmpEnemy.hp):
            tmpEnemy.hp = defeated(tmpHero, tmpEnemy)
            #print("{} defeated Hero with {} HP remaining.".format(tmpEnemy.name, tmpEnemy.hp))
            print("Hero is Dead!! Last seen at position {}!!".format(tmp))
            break
        print("Hero defeated {} with {} HP remaining.".format(tmpEnemy.name, hero.hp))

# Savaş bitti
if(hero.hp > 0):
    print("Hero Survived!")
