 Program app.py dosyasının derlenmesi ile çalışmaktadır.
 Çalıştırılmak istenen dosyanın adı program dosyası içinde verilir.
 Yorum satırları şeklinde kod üzerinde açıklamalar mevcuttur.
 
 
