class Person:

    def __init__(self, resource, hp, attack):
        self.resource = int(resource)
        self.hp = int(hp)
        self.attack = int(attack)

    def personResource(self):
        return self.resource

    def personHp(self):
        return self.hp

    def personAttack(self):
        return self.attack
