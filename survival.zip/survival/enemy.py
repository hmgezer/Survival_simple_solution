class Enemy:

    def __init__(self, name, hp, attack):
        self.name = name
        self.hp = int(hp)
        self.attack = int(attack)

    def enemyName(self):
        return self.name

    def enemyHp(self):
        return self.hp

    def enemyAttack(self):
        return self.attack
